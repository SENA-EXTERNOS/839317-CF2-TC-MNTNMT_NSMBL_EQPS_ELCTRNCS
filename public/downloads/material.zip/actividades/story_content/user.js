function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5V6QormieVs":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

